#include<stdio.h>
#include<stdlib.h>
void tela (void){
	int i;
	system("cls");system("color fc");	
    printf("\n");
	for(i=0;i<40;i++){printf("%c",219);}
	printf("\n%c         Sistema de Alunos            %c\n",219,219);
	for(i=0;i<40;i++){printf("%c",219);}
	printf("\n%c                                      %c",219,219);
	printf("\n%c        (1)  Inserir Alunos           %c",219,219);
	printf("\n%c        (2)  Consultar Alunos         %c",219,219);
	printf("\n%c        (3)  Calcular Media           %c",219,219);
	printf("\n%c        (4)  Sair                     %c",219,219);
	printf("\n%c                                      %c\n",219,219);
	for(i=0;i<40;i++){printf("%c",219);}
	printf("\n\n         Digite uma Op%c%co: ",135,132);
}





